// array to map gesture index to a name
extern const char* GESTURES[];

extern const int num_gestures;

extern const unsigned char g_motion_model[];
//extern const int g_motion_model_len;

